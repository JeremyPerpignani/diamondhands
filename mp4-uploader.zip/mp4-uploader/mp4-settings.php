<?php
// mp4-settings.php

// Add the HTML structure and form elements for the settings page
function mp4_settings_page() {
    ?>
    <div class="wrap">
        <h1>MP4 Uploader Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mp4_settings');
            do_settings_sections('mp4_settings');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Default Video Width</th>
                    <td><input type="number" name="mp4_default_width" value="<?php echo esc_attr(get_option('mp4_default_width')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Default Video Height</th>
                    <td><input type="number" name="mp4_default_height" value="<?php echo esc_attr(get_option('mp4_default_height')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
